import React, { useState } from 'react';
import { Stethoscope, AlertTriangle, Video, Clock, CheckCircle2, ArrowRight, ShieldCheck, Pill, MapPin, Sparkles, User, RefreshCw, MessageSquare } from 'lucide-react';
import { SYMPTOM_DATA, URGENT_CARE_LIST, ON_CALL_DOCTORS, SymptomAssessment } from '../data/medicalData';
import { NavTab } from './Header';

interface QuickCareViewProps {
  onNavigate: (tab: NavTab) => void;
  onOpenBooking: () => void;
}

export const QuickCareView: React.FC<QuickCareViewProps> = ({ onNavigate, onOpenBooking }) => {
  // Symptom Checker State
  const [selectedAssessment, setSelectedAssessment] = useState<SymptomAssessment>(SYMPTOM_DATA[0]);
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(null);

  // Telehealth Simulation State
  const [isInTelehealthRoom, setIsInTelehealthRoom] = useState(false);
  const [telehealthStep, setTelehealthStep] = useState<'queue' | 'connected'>('queue');
  const [chatMessages, setChatMessages] = useState<{ sender: 'doc' | 'user'; text: string; time: string }[]>([
    { sender: 'doc', text: 'Hello! I am Dr. Sarah Jenkins. I am reviewing your preliminary triage check. Where is the discomfort primarily localized today?', time: 'Just now' },
  ]);
  const [userChatInput, setUserChatInput] = useState('');

  // Check-In State for urgent care
  const [checkedInClinicId, setCheckedInClinicId] = useState<string | null>(null);

  // Prescription Quick Refill State
  const [refillRxNumber, setRefillRxNumber] = useState('');
  const [refillDob, setRefillDob] = useState('');
  const [refillSubmitted, setRefillSubmitted] = useState(false);

  const currentOption = selectedOptionIndex !== null ? selectedAssessment.options[selectedOptionIndex] : null;

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userChatInput.trim()) return;

    const newMsg = { sender: 'user' as const, text: userChatInput, time: 'Just now' };
    setChatMessages((prev) => [...prev, newMsg]);
    setUserChatInput('');

    setTimeout(() => {
      setChatMessages((prev) => [
        ...prev,
        {
          sender: 'doc',
          text: 'Understood. Based on your symptoms, your vitals remain within stable outpatient range. I am sending an electronic prescription to ApexCare Central Pharmacy and charting follow-up instructions.',
          time: 'Just now',
        },
      ]);
    }, 1200);
  };

  const handleStartTelehealth = () => {
    setIsInTelehealthRoom(true);
    setTelehealthStep('queue');
    setTimeout(() => {
      setTelehealthStep('connected');
    }, 2000);
  };

  const handleUrgentCheckIn = (clinicId: string) => {
    setCheckedInClinicId(clinicId);
    setTimeout(() => {
      alert('You have been checked in! Your position in the walk-in queue has been held. You will receive an SMS reminder 15 minutes before your estimated time.');
    }, 400);
  };

  const handleRefillSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!refillRxNumber.trim()) return;
    setRefillSubmitted(true);
  };

  return (
    <div className="space-y-16 pb-20">
      {/* Header */}
      <section className="bg-teal-900 text-white pt-28 pb-16 sm:pt-32 sm:pb-20 lg:pt-36 lg:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-300">Fast Triage & Same-Day Relief</span>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
              ApexCare Quick Care & Digital Triage
            </h1>
            <p className="text-base sm:text-lg text-teal-100 leading-relaxed">
              Find the right level of care without unnecessary waiting. Self-triage your symptoms, join an instant virtual doctor queue, or hold your spot at a nearby urgent care center.
            </p>
          </div>
        </div>
      </section>

      {/* 1. Clinical Symptom Checker & Triage Tool */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700">Self-Service Evaluation</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
            Interactive Symptom Triage Assessment
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 max-w-2xl mt-0.5">
            Select your symptom category to receive evidence-based disposition guidance verified by Board-Certified Emergency Physicians.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-slate-200">
          {SYMPTOM_DATA.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setSelectedAssessment(item);
                setSelectedOptionIndex(null);
              }}
              className={`px-4 py-2.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition-all cursor-pointer ${
                selectedAssessment.id === item.id
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
              }`}
            >
              {item.category}
            </button>
          ))}
        </div>

        {/* Triage Questionnaire Container */}
        <div className="p-6 sm:p-8 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-6">
          <div className="space-y-2">
            <h3 className="text-lg font-bold text-slate-900">
              {selectedAssessment.severityQuestion}
            </h3>
            <div className="flex flex-wrap gap-2 text-xs text-slate-500">
              <span className="font-semibold text-slate-700">Common associated symptoms:</span>
              {selectedAssessment.symptoms.map((sym, idx) => (
                <span key={idx} className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-[11px]">
                  {sym}
                </span>
              ))}
            </div>
          </div>

          {/* Options */}
          <div className="space-y-3">
            <span className="text-xs font-semibold text-slate-700 block">Select the statement that matches your current condition:</span>
            {selectedAssessment.options.map((option, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setSelectedOptionIndex(idx)}
                className={`w-full text-left p-4 rounded-xl border transition-all flex items-start justify-between gap-4 cursor-pointer ${
                  selectedOptionIndex === idx
                    ? 'border-teal-600 bg-teal-50/70 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="space-y-1">
                  <span className="text-sm font-semibold text-slate-900 block">{option.label}</span>
                  <span className="text-xs text-slate-500 block">{option.action}</span>
                </div>
                <span className={`text-[11px] font-bold px-2.5 py-1 rounded-md shrink-0 uppercase tracking-wider ${
                  option.level === 'emergency'
                    ? 'bg-red-100 text-red-800'
                    : option.level === 'urgent'
                    ? 'bg-amber-100 text-amber-800'
                    : option.level === 'telehealth'
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-emerald-100 text-emerald-800'
                }`}>
                  {option.timeline}
                </span>
              </button>
            ))}
          </div>

          {/* Triage Disposition Advice Box */}
          {currentOption && (
            <div className={`p-5 rounded-2xl border ${
              currentOption.level === 'emergency'
                ? 'bg-red-50 border-red-200 text-red-950'
                : currentOption.level === 'urgent'
                ? 'bg-amber-50 border-amber-200 text-amber-950'
                : 'bg-teal-50 border-teal-200 text-teal-950'
            }`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 shrink-0" />
                    <h4 className="text-sm font-bold uppercase tracking-wide">
                      Recommended Care Level: {currentOption.level.toUpperCase()}
                    </h4>
                  </div>
                  <p className="text-xs leading-relaxed">{currentOption.action}</p>
                </div>
                <div className="shrink-0 flex items-center gap-2">
                  {currentOption.level === 'emergency' ? (
                    <button
                      onClick={() => onNavigate('helpline')}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-xs"
                    >
                      Call Emergency Dispatch 911
                    </button>
                  ) : currentOption.level === 'urgent' ? (
                    <button
                      onClick={onOpenBooking}
                      className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs"
                    >
                      Reserve Walk-In Urgent Spot
                    </button>
                  ) : (
                    <button
                      onClick={handleStartTelehealth}
                      className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl shadow-xs"
                    >
                      Launch Telehealth Visit Now
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* 2. Instant Virtual Telehealth Queue & Simulation */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="p-8 bg-slate-900 text-white rounded-3xl shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-6 space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-300 bg-teal-950 px-3 py-1 rounded">
              <Video className="w-3.5 h-3.5 text-teal-400" />
              <span>Virtual Urgent Care Room</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
              Connect with an On-Call Doctor in ~3 Minutes
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Skip travel and waiting rooms. Our board-certified physicians diagnose, treat, and prescribe medications for cough, sore throat, allergies, urinary discomfort, minor rashes, and routine medication refills via secure high-definition video.
            </p>
            <div className="pt-2 flex items-center gap-4 text-xs text-slate-400">
              <span className="flex items-center gap-1.5"><Clock className="w-4 h-4 text-teal-400" /> Wait: 3 mins</span>
              <span>·</span>
              <span className="flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-teal-400" /> HIPAA Encrypted</span>
              <span>·</span>
              <span className="text-teal-300 font-semibold">$0 with most insurances</span>
            </div>
            <button
              onClick={handleStartTelehealth}
              className="mt-2 px-6 py-3 bg-teal-600 hover:bg-teal-500 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <Video className="w-4 h-4" />
              <span>Join Virtual Waiting Queue</span>
            </button>
          </div>

          <div className="lg:col-span-6">
            <div className="rounded-2xl overflow-hidden border border-slate-700 shadow-lg relative min-h-[260px]">
              <img
                src="/src/assets/images/quick_care_doctor_1792925316267.jpg"
                alt="ApexCare Telehealth Doctor conducting a digital patient consult"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-3 left-3 right-3 p-3 bg-slate-950/80 backdrop-blur-xs rounded-xl border border-slate-800 text-xs flex items-center justify-between">
                <div>
                  <span className="font-bold text-white block">Dr. Sarah Jenkins, MD</span>
                  <span className="text-slate-400 text-[11px]">Chief Telehealth Attending · Online</span>
                </div>
                <span className="text-[11px] font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                  Ready to Connect
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Telehealth Consultation Active Modal */}
        {isInTelehealthRoom && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <div className="w-full max-w-2xl bg-slate-900 text-white rounded-3xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
              <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="font-bold text-white">APEXCARE SECURE TELE-CONSULT SUITE</span>
                </div>
                <button
                  onClick={() => setIsInTelehealthRoom(false)}
                  className="text-slate-400 hover:text-white text-xs bg-slate-800 px-2.5 py-1 rounded"
                >
                  Leave Consult
                </button>
              </div>

              {telehealthStep === 'queue' ? (
                <div className="p-10 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center mx-auto animate-pulse">
                    <Clock className="w-8 h-8" />
                  </div>
                  <h4 className="text-lg font-bold text-white">Preparing Your Virtual Examination Room</h4>
                  <p className="text-xs text-slate-300">
                    Connecting audio/video streams with Dr. Sarah Jenkins, MD. Checking camera permissions and clinical intake notes...
                  </p>
                </div>
              ) : (
                <div className="flex flex-col flex-1 overflow-hidden">
                  {/* Doctor Video Frame */}
                  <div className="relative bg-slate-950 h-56 flex items-center justify-center border-b border-slate-800">
                    <img
                      src="/src/assets/images/quick_care_doctor_1792925316267.jpg"
                      alt="Doctor on video call"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover opacity-80"
                    />
                    <div className="absolute top-3 left-3 bg-slate-900/80 px-2.5 py-1 rounded text-xs font-semibold">
                      Dr. Sarah Jenkins, MD (Attending)
                    </div>
                    <div className="absolute bottom-3 right-3 w-28 h-20 bg-slate-800 rounded-lg border border-slate-600 overflow-hidden flex items-center justify-center text-center p-1 text-[10px] text-slate-300">
                      Your Camera Active
                    </div>
                  </div>

                  {/* Chat Stream */}
                  <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-900 text-xs">
                    {chatMessages.map((msg, i) => (
                      <div
                        key={i}
                        className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                      >
                        <div
                          className={`max-w-md p-3 rounded-2xl ${
                            msg.sender === 'user'
                              ? 'bg-teal-700 text-white rounded-br-xs'
                              : 'bg-slate-800 text-slate-200 rounded-bl-xs border border-slate-700'
                          }`}
                        >
                          <p>{msg.text}</p>
                          <span className="text-[10px] opacity-60 block mt-1 text-right">{msg.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Chat Input */}
                  <form onSubmit={handleSendChat} className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
                    <input
                      type="text"
                      value={userChatInput}
                      onChange={(e) => setUserChatInput(e.target.value)}
                      placeholder="Type medical query or symptom details..."
                      className="flex-1 px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl"
                    >
                      Send
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        )}
      </section>

      {/* 3. Live Urgent Care Walk-in Wait Times & Online Check-In */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">Walk-In Clinics</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
              Urgent Care Walk-In Locations & Live Wait Times
            </h2>
          </div>
          <p className="text-xs text-slate-500">Wait times updated every 60 seconds</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {URGENT_CARE_LIST.map((clinic) => (
            <div
              key={clinic.id}
              className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-500">Open until {clinic.openUntil}</span>
                  <div className="text-right">
                    <span className="text-xl font-extrabold text-teal-800 tabular-nums">
                      ~{clinic.currentWaitMin} min
                    </span>
                    <span className="block text-[11px] text-slate-400">estimated wait</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-base font-bold text-slate-900">{clinic.name}</h3>
                  <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    <span>{clinic.location}</span>
                  </p>
                </div>

                <div className="flex items-center gap-3 text-xs text-slate-600 pt-1">
                  <span className="flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" /> Rapid PCR & Flu Swabs
                  </span>
                  {clinic.xrayAvailable && (
                    <span className="flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" /> Digital X-Ray On-Site
                    </span>
                  )}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs text-slate-500">{clinic.patientsInQueue} patients currently in queue</span>
                {checkedInClinicId === clinic.id ? (
                  <span className="px-3.5 py-1.5 bg-emerald-100 text-emerald-800 font-bold text-xs rounded-lg flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Spot Held</span>
                  </span>
                ) : (
                  <button
                    onClick={() => handleUrgentCheckIn(clinic.id)}
                    className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                  >
                    Check In Online
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Express Prescription Refill Form */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 bg-slate-100 rounded-3xl border border-slate-200">
          <div className="max-w-xl mx-auto text-center space-y-4">
            <div className="w-12 h-12 rounded-xl bg-teal-100 text-teal-800 flex items-center justify-center mx-auto">
              <Pill className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-900">Express Prescription Refill</h3>
              <p className="text-xs text-slate-600 mt-1">
                Enter your Rx Number from your pill bottle to have it filled at ApexCare 24/7 Compounding Pharmacy or delivered directly to your door.
              </p>
            </div>

            {refillSubmitted ? (
              <div className="p-5 bg-white rounded-2xl border border-teal-200 text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-teal-600 mx-auto" />
                <h4 className="text-sm font-bold text-slate-900">Refill Request Dispatched</h4>
                <p className="text-xs text-slate-600">
                  Rx #{refillRxNumber} is being prepared by our central pharmacy. Estimated pickup readiness in 45 minutes.
                </p>
                <button
                  onClick={() => setRefillSubmitted(false)}
                  className="text-xs text-teal-700 font-semibold hover:underline"
                >
                  Submit another refill
                </button>
              </div>
            ) : (
              <form onSubmit={handleRefillSubmit} className="space-y-3 text-left">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Prescription (Rx) Number</label>
                    <input
                      type="text"
                      required
                      value={refillRxNumber}
                      onChange={(e) => setRefillRxNumber(e.target.value)}
                      placeholder="e.g. RX-904128"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Patient Date of Birth</label>
                    <input
                      type="date"
                      required
                      value={refillDob}
                      onChange={(e) => setRefillDob(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-teal-700 hover:bg-teal-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Verify & Process Refill
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};
