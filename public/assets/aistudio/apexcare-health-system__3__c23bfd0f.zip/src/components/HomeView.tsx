import React from 'react';
import { Phone, ArrowRight, CheckCircle2, ChevronRight, AlertCircle, Building2 } from 'lucide-react';
import { HELPLINE_DATA, ON_CALL_DOCTORS, HelplineItem } from '../data/medicalData';
import { NavTab } from './Header';

interface HomeViewProps {
  onNavigate: (tab: NavTab) => void;
  onCallHelpline: (item: HelplineItem) => void;
  onOpenBooking: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ onNavigate, onCallHelpline, onOpenBooking }) => {
  const emergencyLine = HELPLINE_DATA[0];

  return (
    <div className="space-y-16 pb-20">
      {/* Hero Section */}
      <section className="relative bg-slate-900 text-white overflow-hidden">
        {/* Measured scrim over generated hero photograph */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/hero_medical_center_1792925315093.jpg"
            alt="ApexCare Medical Center modern pavilion lobby with clinical physicians"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-25"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/90 to-slate-900/60" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 sm:pt-32 sm:pb-20 lg:pt-36 lg:pb-24">
          <div className="max-w-3xl space-y-7">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-300 bg-teal-950/80 px-3.5 py-1.5 rounded-md border border-teal-800/80">
              <span className="w-2 h-2 rounded-full bg-teal-400" />
              <span>Level I Regional Trauma Center · 24/7 Clinical Triage</span>
            </div>

            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight" style={{ textWrap: 'balance' }}>
              Immediate Medical Care, Whenever Every Second Counts.
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              Connect directly with board-certified physicians, monitor real-time clinical availability, and dispatch emergency response teams across our regional hospital network.
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => onCallHelpline(emergencyLine)}
                className="px-6 py-3.5 bg-red-600 hover:bg-red-700 text-white font-semibold text-sm rounded-xl shadow-lg transition-all flex items-center gap-2.5 cursor-pointer"
              >
                <Phone className="w-4 h-4 text-white" />
                <span>Call Emergency Helpline (911)</span>
              </button>

              <button
                onClick={() => onNavigate('quick-care')}
                className="px-6 py-3.5 bg-white hover:bg-slate-100 text-slate-900 font-semibold text-sm rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>Start Quick Care Triage</span>
                <ArrowRight className="w-4 h-4 text-slate-700" />
              </button>
            </div>

            {/* Trust Evidence adjacent to hero */}
            <div className="pt-6 border-t border-slate-800/80 grid grid-cols-3 gap-6 text-xs text-slate-400 max-w-xl">
              <div>
                <span className="block text-2xl font-bold text-white tabular-nums">4.2 min</span>
                <span className="text-slate-300">Avg Ambulance Dispatch</span>
              </div>
              <div>
                <span className="block text-2xl font-bold text-white tabular-nums">24 / 7</span>
                <span className="text-slate-300">Board-Certified ER Staff</span>
              </div>
              <div>
                <span className="block text-2xl font-bold text-white tabular-nums">6 Centers</span>
                <span className="text-slate-300">Hospitals & Walk-in Facilities</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Priority Medical Helpline Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-6 sm:p-8 bg-gradient-to-r from-red-600 to-rose-700 rounded-2xl text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-red-200 uppercase tracking-wider">
              <AlertCircle className="w-4 h-4" />
              <span>Immediate Life-Threatening Emergency Support</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Need Direct Medical Assistance Right Now?
            </h2>
            <p className="text-xs sm:text-sm text-red-100 max-w-xl">
              Our 24-hour medical helpline connects you directly to emergency dispatchers, poison control toxicologists, and registered triage nurses.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => onCallHelpline(emergencyLine)}
              className="px-5 py-3 bg-white text-red-700 hover:bg-red-50 font-bold text-sm rounded-xl shadow-md transition-colors flex items-center gap-2 cursor-pointer"
            >
              <Phone className="w-4 h-4" />
              <span>Dial Emergency 911</span>
            </button>
            <button
              onClick={() => onNavigate('helpline')}
              className="px-5 py-3 bg-red-800 hover:bg-red-900 text-white font-semibold text-sm rounded-xl border border-red-500/50 transition-colors cursor-pointer"
            >
              View All Helplines & Direct Extensions
            </button>
          </div>
        </div>
      </section>

      {/* Core Medical Capabilities & Services */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">Specialized Healthcare</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
              Integrated Clinical Infrastructure
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 max-w-md">
            Seamless continuum of care from acute emergency intervention to outpatient surgical follow-up.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-teal-300 transition-all space-y-4">
            <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold text-lg">
              01
            </div>
            <h3 className="text-lg font-bold text-slate-900">Level I Emergency & Trauma</h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              24/7 dedicated acute resuscitation bays, rapid CT within 8 minutes of arrival, biplane neuro-interventional stroke suites, and in-house surgical trauma teams.
            </p>
            <div className="pt-2 text-xs text-slate-500 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
              <span>Full Comprehensive Stroke Center Accredited</span>
            </div>
          </div>

          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-teal-300 transition-all space-y-4">
            <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold text-lg">
              02
            </div>
            <h3 className="text-lg font-bold text-slate-900">Virtual Quick Care & Telehealth</h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Skip clinic waiting rooms for non-emergency acute illnesses. Connect with our on-call family physicians within 15 minutes for diagnoses, sick notes, and instant e-prescriptions.
            </p>
            <div className="pt-2 text-xs text-slate-500 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
              <span>Direct Pharmacy Routing & Refills</span>
            </div>
          </div>

          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-teal-300 transition-all space-y-4">
            <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold text-lg">
              03
            </div>
            <h3 className="text-lg font-bold text-slate-900">Regional Diagnostic & Specialty Labs</h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Advanced 3T silent MRI, dual-source 256-slice cardiac CT, digital 3D mammography, and on-site molecular microbiology for rapid 45-minute pathogen identification.
            </p>
            <div className="pt-2 text-xs text-slate-500 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
              <span>Same-Day Digital Patient Portal Results</span>
            </div>
          </div>
        </div>
      </section>

      {/* On-Call Physicians Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">Clinical Leadership</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
              On-Call Physicians & Department Heads
            </h2>
          </div>
          <button
            onClick={() => onNavigate('about')}
            className="text-xs font-semibold text-teal-700 hover:text-teal-900 flex items-center gap-1 cursor-pointer"
          >
            <span>Meet Medical Advisory Board</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {ON_CALL_DOCTORS.map((doc) => (
            <div key={doc.id} className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`text-[11px] font-medium px-2 py-0.5 rounded ${
                    doc.availableToday ? 'bg-emerald-50 text-emerald-800' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {doc.availableToday ? 'Available Today' : 'Scheduled Tomorrow'}
                  </span>
                  <span className="text-xs font-bold text-slate-700 tabular-nums">★ {doc.rating}</span>
                </div>
                <h4 className="text-base font-bold text-slate-900">{doc.name}</h4>
                <p className="text-xs font-medium text-teal-700">{doc.specialty}</p>
                <p className="text-xs text-slate-500 leading-snug">{doc.credentials}</p>
              </div>

              <div className="pt-3 border-t border-slate-100 text-xs">
                <span className="text-slate-400 block text-[11px]">Primary Hospital</span>
                <span className="font-semibold text-slate-800 block">{doc.hospital}</span>
                <button
                  onClick={onOpenBooking}
                  className="mt-3 w-full py-2 bg-teal-50 hover:bg-teal-100 text-teal-800 font-semibold rounded-lg text-xs transition-colors cursor-pointer"
                >
                  Book Consultation
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Facilities Teaser Split */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-100 rounded-3xl overflow-hidden border border-slate-200 grid grid-cols-1 lg:grid-cols-12 items-stretch">
          <div className="lg:col-span-6 p-8 sm:p-12 flex flex-col justify-center space-y-5">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700">Network Directory</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              State-of-the-Art Medical Facilities Near You
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Locate fully equipped acute hospitals, specialty trauma centers, community urgent care clinics, and 24-hour compounding pharmacies with live bed occupancy and wait time telemetry.
            </p>
            <div className="pt-2 flex flex-wrap gap-4">
              <button
                onClick={() => onNavigate('facilities')}
                className="px-5 py-3 bg-teal-700 hover:bg-teal-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Building2 className="w-4 h-4" />
                <span>Explore All Medical Facilities</span>
              </button>
              <button
                onClick={() => onNavigate('contact')}
                className="px-5 py-3 bg-white hover:bg-slate-50 text-slate-800 font-semibold text-xs rounded-xl border border-slate-300 transition-colors cursor-pointer"
              >
                Clinic Directions & Contact
              </button>
            </div>
          </div>
          <div className="lg:col-span-6 min-h-[300px] relative">
            <img
              src="/src/assets/images/medical_facility_exterior_1792925315899.jpg"
              alt="ApexCare Hospital architectural exterior"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>
    </div>
  );
};
