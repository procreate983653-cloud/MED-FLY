import React, { useState } from 'react';
import { User, LogOut } from 'lucide-react';
import { UserSession } from './AuthModal';

export type NavTab = 'home' | 'about' | 'helpline' | 'quick-care' | 'facilities' | 'contact';

interface HeaderProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  session: UserSession | null;
  onOpenLogin: () => void;
  onOpenDashboard: () => void;
  onSignOut: () => void;
  onTriggerSOS: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  session,
  onOpenLogin,
  onOpenDashboard,
  onSignOut,
}) => {
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  const navItems: { id: NavTab; label: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'helpline', label: 'Medical Helpline' },
    { id: 'quick-care', label: 'Quick Care' },
    { id: 'facilities', label: 'Medical Facilities' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleNavClick = (tab: NavTab) => {
    onSelectTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="absolute top-0 left-0 right-0 z-40 bg-slate-950/30 backdrop-blur-xs border-b border-white/10 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-4 h-20">
          
          {/* Logo of website in a curved and covered-edge square */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2.5 text-left focus:outline-none shrink-0 group cursor-pointer"
            title="ApexCare Health - Home"
            aria-label="ApexCare Health Logo"
          >
            {/* Curved and covered edge square emblem */}
            <div className="relative w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-br from-teal-400 via-teal-600 to-emerald-700 p-0.5 shadow-lg shadow-teal-950/40 border border-teal-200/30 flex items-center justify-center transition-transform group-hover:scale-105 active:scale-95 overflow-hidden">
              <div className="w-full h-full rounded-[14px] bg-slate-950/85 backdrop-blur-xs flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-radial from-teal-500/25 to-transparent pointer-events-none" />
                {/* Medical Cross & Pulse Wave */}
                <svg
                  className="w-6 h-6 text-teal-400 group-hover:text-teal-300 transition-colors drop-shadow-xs"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M12 3v4m0 10v4m-9-9h4m10 0h4" strokeWidth="2.5" stroke="#2dd4bf" />
                  <path d="M4 12h3.5l1.5-3 3 6 2-4 1.5 1h4.5" stroke="#ffffff" strokeWidth="2" />
                </svg>
              </div>
            </div>

            {/* Brand title in normal text */}
            <span className="font-sans font-extrabold tracking-tight text-base sm:text-lg text-white group-hover:text-teal-300 transition-colors hidden sm:inline">
              ApexCare
            </span>
          </button>

          {/* Right Group: Navigation Links shifted toward right + Login Icon */}
          <div className="flex items-center gap-3 sm:gap-5 lg:gap-7 ml-auto overflow-hidden">
            {/* Main Navigation in normal text */}
            <nav className="flex items-center gap-2.5 sm:gap-4 lg:gap-6 overflow-x-auto py-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`font-sans font-medium transition-all whitespace-nowrap shrink-0 py-1 cursor-pointer border-b-2 text-xs sm:text-sm ${
                    activeTab === item.id
                      ? 'border-teal-400 text-white font-semibold'
                      : 'border-transparent text-slate-200 hover:text-white hover:border-slate-400/50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Top Right Corner: Clean Login Icon */}
            <div className="flex items-center shrink-0 pl-1 border-l border-white/10">
              {session ? (
                <div className="relative">
                  <button
                    onClick={() => setUserMenuOpen(!userMenuOpen)}
                    className="w-9 h-9 rounded-full bg-teal-500 hover:bg-teal-400 text-slate-950 flex items-center justify-center font-bold text-xs shadow-md transition-all cursor-pointer"
                    title={`${session.name} - Profile`}
                    aria-label="User Profile"
                  >
                    {session.name.substring(0, 2).toUpperCase()}
                  </button>

                  {userMenuOpen && (
                    <div className="absolute right-0 mt-2 w-56 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 py-1.5 z-50 text-xs">
                      <div className="px-3.5 py-2 border-b border-slate-800">
                        <p className="font-semibold text-white truncate">{session.name}</p>
                        <p className="text-slate-400 text-[11px] truncate">{session.email}</p>
                        <span className="inline-block mt-1 text-[10px] uppercase font-bold tracking-wider text-teal-400 bg-teal-950 px-2 py-0.5 rounded border border-teal-800">
                          {session.role === 'doctor' ? 'Staff Clinician' : 'Patient Account'}
                        </span>
                      </div>

                      <button
                        onClick={() => {
                          setUserMenuOpen(false);
                          onOpenDashboard();
                        }}
                        className="w-full text-left px-3.5 py-2 text-slate-200 hover:bg-slate-800 flex items-center gap-2 cursor-pointer font-sans"
                      >
                        <User className="w-3.5 h-3.5 text-teal-400" />
                        <span>{session.role === 'doctor' ? 'Clinical Control Desk' : 'Patient Health Portal'}</span>
                      </button>

                      <button
                        onClick={() => {
                          setUserMenuOpen(false);
                          onSignOut();
                        }}
                        className="w-full text-left px-3.5 py-2 text-red-400 hover:bg-slate-800 flex items-center gap-2 border-t border-slate-800 cursor-pointer font-sans"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <button
                  onClick={onOpenLogin}
                  className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 border border-white/20 text-white flex items-center justify-center transition-all cursor-pointer shadow-xs group"
                  title="Sign In"
                  aria-label="Login Icon"
                >
                  <User className="w-4 h-4 group-hover:text-teal-300 transition-colors" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
