import React from 'react';
import { ShieldCheck, Award, HeartHandshake, CheckCircle2, Users, Building, Activity, PhoneCall } from 'lucide-react';
import { NavTab } from './Header';

interface AboutViewProps {
  onNavigate: (tab: NavTab) => void;
  onOpenBooking: () => void;
}

export const AboutView: React.FC<AboutViewProps> = ({ onNavigate, onOpenBooking }) => {
  return (
    <div className="space-y-16 pb-20">
      {/* Editorial Header */}
      <section className="bg-slate-900 text-white pt-28 pb-16 sm:pt-32 sm:pb-20 lg:pt-36 lg:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Our Clinical Mission & Foundation</span>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Pioneering Acute Care, Patient Dignity, and Rapid Response.
            </h1>
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
              Founded with the mission to eliminate preventable emergency delays, ApexCare Health System operates an integrated network of Level I Trauma centers, regional acute hospitals, community urgent clinics, and round-the-clock tele-triage specialists.
            </p>
          </div>
        </div>
      </section>

      {/* Hero Visual & Pillars */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-6 rounded-2xl overflow-hidden border border-slate-200 shadow-md">
            <img
              src="/src/assets/images/medical_team_specialists_1792925316495.jpg"
              alt="ApexCare senior clinical specialists and surgeons"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          <div className="lg:col-span-6 space-y-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-teal-700">Clinical Excellence</span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
                A Unified Continuum of Acute Medical Care
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Every facility within the ApexCare umbrella adheres to the most stringent international medical protocols. From our trauma resuscitation teams to digital telehealth practitioners, patient safety is supported by real-time clinical decision intelligence and multidisciplinary oversight.
            </p>

            <div className="space-y-3 pt-2">
              <div className="flex items-start gap-3 p-3 bg-white rounded-xl border border-slate-200">
                <ShieldCheck className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Joint Commission International (JCI) Gold Seal</h4>
                  <p className="text-xs text-slate-500">Recognized for top-decile clinical quality, antibiotic stewardship, and surgical safety metrics.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-white rounded-xl border border-slate-200">
                <Award className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Comprehensive Stroke & STEMI Heart Center</h4>
                  <p className="text-xs text-slate-500">Average door-to-balloon angioplasty time of under 48 minutes, significantly exceeding national standards.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-white rounded-xl border border-slate-200">
                <HeartHandshake className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Patient-First Transparent Healthcare</h4>
                  <p className="text-xs text-slate-500">Immediate access to your electronic health records, transparent pricing with no surprise billing.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quantitative Impact Metrics */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-10 bg-slate-900 text-white rounded-3xl shadow-xl">
          <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-400">By the Numbers</span>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white">Proven Clinical Outcomes</h3>
            <p className="text-xs sm:text-sm text-slate-400">Documented metrics audited across our 6 regional medical facilities over the past calendar year.</p>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 text-center">
            <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-800">
              <span className="block text-3xl sm:text-4xl font-extrabold text-teal-400 font-mono tabular-nums">4.2 min</span>
              <span className="text-xs text-slate-300 mt-1 block">Average Emergency Dispatch</span>
            </div>
            <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-800">
              <span className="block text-3xl sm:text-4xl font-extrabold text-teal-400 font-mono tabular-nums">140,000+</span>
              <span className="text-xs text-slate-300 mt-1 block">Patients Treated Annually</span>
            </div>
            <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-800">
              <span className="block text-3xl sm:text-4xl font-extrabold text-teal-400 font-mono tabular-nums">450+</span>
              <span className="text-xs text-slate-300 mt-1 block">Board-Certified Specialists</span>
            </div>
            <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-800">
              <span className="block text-3xl sm:text-4xl font-extrabold text-teal-400 font-mono tabular-nums">99.4%</span>
              <span className="text-xs text-slate-300 mt-1 block">Acute STEMI Survival Rate</span>
            </div>
          </div>
        </div>
      </section>

      {/* Clinical Leadership & Advisory Board */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700">Executive Leadership</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
            Clinical Advisory Board
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 max-w-xl mt-1">
            Renowned department chiefs and medical researchers directing standards of emergency, pediatric, and surgical excellence.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-800 font-bold text-base flex items-center justify-center">
              DR
            </div>
            <div>
              <h4 className="text-base font-bold text-slate-900">Dr. Julian Vance, MD, FACS</h4>
              <p className="text-xs font-semibold text-teal-700">Chief Medical Officer & Trauma Director</p>
              <p className="text-xs text-slate-500 mt-0.5">Harvard Medical School · Former Chief of Acute Surgery at Johns Hopkins</p>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed pt-2 border-t border-slate-100">
              Leads ApexCare trauma readiness protocols and rapid helicopter air-ambulance coordination across the tri-county area.
            </p>
          </div>

          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-800 font-bold text-base flex items-center justify-center">
              DR
            </div>
            <div>
              <h4 className="text-base font-bold text-slate-900">Dr. Sarah Jenkins, MD</h4>
              <p className="text-xs font-semibold text-teal-700">Director of Tele-Triage & Urgent Care</p>
              <p className="text-xs text-slate-500 mt-0.5">Stanford Health Care Fellow · Board Certified ABEM / ABFM</p>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed pt-2 border-t border-slate-100">
              Architect of the ApexCare Quick Care virtual assessment algorithm, reducing non-urgent ER waiting room congestion by 38%.
            </p>
          </div>

          <div className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-800 font-bold text-base flex items-center justify-center">
              DR
            </div>
            <div>
              <h4 className="text-base font-bold text-slate-900">Dr. Elena Rostova, MD, FAAP</h4>
              <p className="text-xs font-semibold text-teal-700">Head of Pediatric Emergency Services</p>
              <p className="text-xs text-slate-500 mt-0.5">Boston Children's Hospital Fellow · Pediatric Intensive Care</p>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed pt-2 border-t border-slate-100">
              Specializes in neonatal resuscitation, pediatric airway trauma, and compassionate family-centered pediatric emergency care.
            </p>
          </div>
        </div>
      </section>

      {/* Call to Action Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 bg-teal-900 text-white rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-xl sm:text-2xl font-bold text-white">Have Questions or Need to Schedule Care?</h3>
            <p className="text-xs sm:text-sm text-teal-200 max-w-lg">
              Our patient navigators are available to assist with insurance verification, medical record transfers, and doctor consultations.
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenBooking}
              className="px-5 py-3 bg-white hover:bg-teal-50 text-teal-900 font-semibold text-xs rounded-xl transition-colors"
            >
              Book an Appointment
            </button>
            <button
              onClick={() => onNavigate('contact')}
              className="px-5 py-3 bg-teal-800 hover:bg-teal-700 text-white font-semibold text-xs rounded-xl border border-teal-600 transition-colors"
            >
              Contact Directory
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
