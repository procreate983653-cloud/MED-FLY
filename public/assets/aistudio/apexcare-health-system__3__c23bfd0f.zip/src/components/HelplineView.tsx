import React, { useState } from 'react';
import { Phone, PhoneCall, AlertTriangle, Clock, ShieldCheck, HeartPulse, CheckCircle2, ArrowRight, Activity, BellRing } from 'lucide-react';
import { HELPLINE_DATA, HelplineItem } from '../data/medicalData';

interface HelplineViewProps {
  onCallHelpline: (item: HelplineItem) => void;
}

export const HelplineView: React.FC<HelplineViewProps> = ({ onCallHelpline }) => {
  const [callbackName, setCallbackName] = useState('');
  const [callbackPhone, setCallbackPhone] = useState('');
  const [callbackCategory, setCallbackCategory] = useState('General Clinical Tele-Triage');
  const [callbackRequested, setCallbackRequested] = useState(false);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('All');

  const categories = ['All', 'Emergency', 'Tele-Triage', 'Pediatrics', 'Poison & Toxic', 'Mental Health', 'Senior'];

  const filteredHelplines = selectedCategoryFilter === 'All'
    ? HELPLINE_DATA
    : HELPLINE_DATA.filter((h) => h.category === selectedCategoryFilter);

  const handleRequestCallback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!callbackPhone.trim()) return;
    setCallbackRequested(true);
  };

  return (
    <div className="space-y-16 pb-20">
      {/* Header Banner */}
      <section className="bg-red-950 text-white pt-28 pb-16 sm:pt-32 sm:pb-20 lg:pt-36 lg:pb-24 border-b border-red-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-red-300 uppercase tracking-wider bg-red-900/60 px-3 py-1.5 rounded border border-red-800">
              <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
              <span>Priority Medical Dispatch & Clinical Tele-Triage</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
              24/7 Medical Helpline Directory
            </h1>
            <p className="text-base sm:text-lg text-red-100 leading-relaxed">
              Immediate, confidential medical guidance staffed by registered triage nurses, emergency medicine specialists, and accredited toxicologists. Free of charge to all regional patients.
            </p>
          </div>
        </div>
      </section>

      {/* Critical Life-Threatening Alert */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-5 sm:p-6 bg-red-50 border border-red-200 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-xs">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-red-950">Is this a life-threatening acute emergency?</h3>
              <p className="text-xs text-red-800 mt-0.5">
                For active chest crushing, inability to breathe, sudden stroke symptoms, severe arterial hemorrhage, or unconsciousness, dial 911 immediately or proceed to the nearest emergency trauma bay.
              </p>
            </div>
          </div>
          <button
            onClick={() => onCallHelpline(HELPLINE_DATA[0])}
            className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-md transition-all shrink-0 flex items-center gap-2 cursor-pointer"
          >
            <Phone className="w-4 h-4 text-white" />
            <span>Connect to 911 Dispatch</span>
          </button>
        </div>
      </section>

      {/* Interactive Category Filter Tabs (Single-line controls with working handlers) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4 border-b border-slate-200 pb-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
              Select Hotline Department
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">Direct lines with average response under 30 seconds</p>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl overflow-x-auto max-w-full">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategoryFilter(cat)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedCategoryFilter === cat
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Helpline Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredHelplines.map((item) => (
            <div
              key={item.id}
              className="p-6 bg-white rounded-2xl border border-slate-200 shadow-xs hover:border-teal-300 transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-teal-800 bg-teal-50 px-2.5 py-0.5 rounded-md border border-teal-100">
                    {item.category}
                  </span>
                  <div className="flex items-center gap-1 text-xs text-slate-500 font-medium">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span className="tabular-nums">Avg {item.avgResponseSeconds}s</span>
                  </div>
                </div>

                <div>
                  <h3 className="text-base font-bold text-slate-900 leading-snug">{item.name}</h3>
                  <p className="text-sm font-mono font-bold text-teal-700 mt-1">{item.number}</p>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed">{item.description}</p>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">{item.availability}</span>
                <button
                  onClick={() => onCallHelpline(item)}
                  className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Call Now</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Immediate First Aid Guides (Life Support Directives) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700">Clinical Protocol</span>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
            Emergency First-Aid Quick Directives
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">Critical actions to perform while emergency medical responders are in transit</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
          <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2">
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-red-100 text-red-700 font-mono text-xs flex items-center justify-center font-bold">1</span>
              <span>Adult Hands-Only CPR</span>
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Place hands center of chest. Push hard and fast at 100 to 120 compressions per minute (to the beat of "Stayin' Alive") until paramedics arrive.
            </p>
          </div>

          <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2">
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-red-100 text-red-700 font-mono text-xs flex items-center justify-center font-bold">2</span>
              <span>Choking / Airway Block</span>
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Perform rapid upward abdominal thrusts (Heimlich maneuver) just above the navel. If unresponsive, lower to ground and begin CPR compressions.
            </p>
          </div>

          <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2">
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-red-100 text-red-700 font-mono text-xs flex items-center justify-center font-bold">3</span>
              <span>Arterial Bleeding Control</span>
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Apply firm, uninterrupted direct pressure with sterile gauze or clean cloth. If limb hemorrhage does not stop, apply an approved tourniquet 2 inches above wound.
            </p>
          </div>

          <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2">
            <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-lg bg-red-100 text-red-700 font-mono text-xs flex items-center justify-center font-bold">4</span>
              <span>FAST Stroke Recognition</span>
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              <strong>F</strong>ace drooping, <strong>A</strong>rm weakness, <strong>S</strong>peech difficulty, <strong>T</strong>ime to call 911. Do not administer aspirin until hospital CT confirms type.
            </p>
          </div>
        </div>
      </section>

      {/* Priority Callback Request Module */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 bg-slate-900 text-white rounded-3xl border border-slate-800 shadow-xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-6 space-y-3">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-teal-400 bg-teal-950 px-2.5 py-1 rounded">
              <BellRing className="w-3.5 h-3.5 text-teal-400" />
              <span>Priority Nurse Callback Service</span>
            </div>
            <h3 className="text-2xl font-bold text-white">Can't Stay on Hold? Request an Instant Callback</h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Enter your mobile phone number. Our automated tele-triage routing system will maintain your exact position in queue and call your line the moment a registered nurse is free.
            </p>
          </div>

          <div className="lg:col-span-6">
            {callbackRequested ? (
              <div className="p-6 bg-slate-800 rounded-2xl border border-teal-500/40 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h4 className="text-base font-bold text-white">Callback Request Confirmed</h4>
                <p className="text-xs text-slate-300">
                  You are positioned <strong className="text-teal-300">#2 in queue</strong>. Expected callback within 3 to 5 minutes at <span className="font-mono text-white">{callbackPhone}</span>.
                </p>
                <button
                  onClick={() => setCallbackRequested(false)}
                  className="text-xs text-teal-400 hover:underline"
                >
                  Request another callback
                </button>
              </div>
            ) : (
              <form onSubmit={handleRequestCallback} className="p-6 bg-slate-800/80 rounded-2xl border border-slate-700 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Your Full Name</label>
                    <input
                      type="text"
                      required
                      value={callbackName}
                      onChange={(e) => setCallbackName(e.target.value)}
                      placeholder="e.g. Marcus Reid"
                      className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">Mobile Phone</label>
                    <input
                      type="tel"
                      required
                      value={callbackPhone}
                      onChange={(e) => setCallbackPhone(e.target.value)}
                      placeholder="(555) 000-0000"
                      className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Specialized Helpline</label>
                  <select
                    value={callbackCategory}
                    onChange={(e) => setCallbackCategory(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    <option value="General Clinical Tele-Triage">ApexCare Registered Nurse Tele-Triage</option>
                    <option value="Pediatric Emergency">Pediatric Emergency Advice</option>
                    <option value="Senior & Geriatric">Senior & Geriatric Urgent Care</option>
                    <option value="Poison & Toxicology">Poison & Toxicology Consultation</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  Hold My Place & Call Me Back
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};
