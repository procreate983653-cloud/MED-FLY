import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send, CheckCircle2, ShieldCheck, Building2, HelpCircle, Navigation } from 'lucide-react';

export const ContactView: React.FC = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    department: 'General Patient Inquiry',
    message: '',
    urgency: 'Routine (Reply within 24 business hours)',
  });
  const [submitted, setSubmitted] = useState(false);
  const [trackingId, setTrackingId] = useState('');

  const departments = [
    {
      name: 'Emergency & Acute Trauma Care',
      phone: '(555) 234-8000 (Ext. 1)',
      email: 'emergency@apexcare.org',
      hours: '24 Hours / 7 Days',
      location: 'Ground Floor, North Pavilion Canopy',
    },
    {
      name: 'Outpatient Appointments & Referrals',
      phone: '(555) 234-8020 (Ext. 2)',
      email: 'appointments@apexcare.org',
      hours: '7:30 AM – 6:00 PM Mon-Fri',
      location: 'Rotunda Building, 2nd Floor Suite 200',
    },
    {
      name: 'Patient Billing & Health Insurance',
      phone: '(555) 234-8055 (Ext. 3)',
      email: 'billing@apexcare.org',
      hours: '8:00 AM – 5:00 PM Mon-Fri',
      location: 'Financial Advocacy Center, 1st Floor',
    },
    {
      name: 'Health Records & HIPAA Releases',
      phone: '(555) 234-8090 (Ext. 4)',
      email: 'him-records@apexcare.org',
      hours: '8:00 AM – 4:30 PM Mon-Fri',
      location: 'Clinical Archives, Lower Level B',
    },
    {
      name: 'International & Language Services',
      phone: '(555) 234-8077 (Ext. 5)',
      email: 'globalcare@apexcare.org',
      hours: '24/7 Translation Operators On-Demand',
      location: 'Patient Hospitality Lounge, Main Tower',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.firstName.trim() || !formData.email.trim() || !formData.message.trim()) return;

    const code = `INQ-${Math.floor(100000 + Math.random() * 900000)}`;
    setTrackingId(code);
    setSubmitted(true);
  };

  return (
    <div className="space-y-16 pb-20">
      {/* Header */}
      <section className="bg-slate-900 text-white pt-28 pb-16 sm:pt-32 sm:pb-20 lg:pt-36 lg:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Direct Communication</span>
            <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Contact ApexCare Health System
            </h1>
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
              Reach clinical departments, coordinate physician referrals, speak with billing advocates, or plan your clinic arrival.
            </p>
          </div>
        </div>
      </section>

      {/* Main Grid: Form + Department Directory */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left: Contact Form */}
          <div className="lg:col-span-7 bg-white p-6 sm:p-8 rounded-2xl border border-slate-200 shadow-xs">
            <div className="space-y-2 mb-6">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-700">Send an Inquiry</span>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                Patient Message & Consultation Request
              </h2>
              <p className="text-xs text-slate-500">
                Non-emergency clinical inquiries will be routed to the appropriate department coordinator.
              </p>
            </div>

            {submitted ? (
              <div className="p-8 bg-teal-50 rounded-2xl border border-teal-200 text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-teal-600 text-white flex items-center justify-center mx-auto shadow-xs">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">Message Received</h3>
                <p className="text-xs text-slate-600 max-w-md mx-auto">
                  Your inquiry has been logged under reference tracking ticket{' '}
                  <strong className="text-teal-800 font-mono">{trackingId}</strong>. A department representative will reply to {formData.email} within 24 hours.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setFormData({
                      firstName: '',
                      lastName: '',
                      email: '',
                      phone: '',
                      department: 'General Patient Inquiry',
                      message: '',
                      urgency: 'Routine (Reply within 24 business hours)',
                    });
                  }}
                  className="mt-4 px-4 py-2 bg-teal-700 text-white text-xs font-semibold rounded-lg"
                >
                  Submit Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">First Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                      placeholder="e.g. Rachel"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Last Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                      placeholder="e.g. Thorne"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="patient@example.com"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Contact Phone</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="(555) 000-0000"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Target Department</label>
                    <select
                      value={formData.department}
                      onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-teal-600"
                    >
                      <option value="General Patient Inquiry">General Patient Inquiry</option>
                      <option value="Appointments & Scheduling">Appointments & Scheduling</option>
                      <option value="Billing & Health Insurance">Billing & Health Insurance</option>
                      <option value="Medical Records (HIPAA)">Medical Records & Release</option>
                      <option value="Patient Advocacy / Ombudsman">Patient Rights & Advocacy</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">Inquiry Urgency</label>
                    <select
                      value={formData.urgency}
                      onChange={(e) => setFormData({ ...formData, urgency: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-teal-600"
                    >
                      <option value="Routine (Reply within 24 business hours)">Routine (Within 24 Hours)</option>
                      <option value="Priority Care Follow-Up (Within 4 Hours)">Priority Follow-Up (Within 4 Hours)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Message Details *</label>
                  <textarea
                    rows={4}
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Provide details regarding your inquiry, preferred physician, or appointment timeline..."
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-4 bg-teal-700 hover:bg-teal-800 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  <span>Transmit Confidential Message</span>
                </button>
              </form>
            )}
          </div>

          {/* Right: Department Phone Extensions */}
          <div className="lg:col-span-5 space-y-4">
            <div className="space-y-1">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-700">Telephone Directory</span>
              <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
                Hospital Direct Extensions
              </h2>
            </div>

            <div className="space-y-3">
              {departments.map((dept, i) => (
                <div key={i} className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-1.5">
                  <h4 className="text-xs font-bold text-slate-900">{dept.name}</h4>
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono font-bold text-teal-800">{dept.phone}</span>
                    <span className="text-slate-400 text-[11px]">{dept.hours}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                    <span>{dept.location}</span>
                  </p>
                </div>
              ))}
            </div>

            <div className="p-4 bg-slate-100 rounded-2xl border border-slate-200 space-y-2 text-xs text-slate-600">
              <div className="flex items-center gap-2 font-bold text-slate-900">
                <Navigation className="w-4 h-4 text-teal-700" />
                <span>Directions & Transit Guidance</span>
              </div>
              <p>
                Metro Blue Line: Exit at <em>Wellness Plaza Station</em>. Buses #42 and #108 stop directly outside the Main Entrance Rotunda.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
