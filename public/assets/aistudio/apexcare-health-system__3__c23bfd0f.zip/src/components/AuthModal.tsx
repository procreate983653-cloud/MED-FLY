import React, { useState } from 'react';
import { User, Lock, Mail, ShieldCheck, Stethoscope, ArrowRight, X, CheckCircle2 } from 'lucide-react';
import { DEMO_PATIENT } from '../data/medicalData';

export interface UserSession {
  role: 'patient' | 'doctor';
  name: string;
  email: string;
  details: typeof DEMO_PATIENT | { name: string; title: string; dept: string; id: string };
}

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (session: UserSession) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLoginSuccess }) => {
  const [tab, setTab] = useState<'patient' | 'doctor' | 'register'>('patient');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isOpen) return null;

  const handleDemoPatientLogin = () => {
    setError('');
    const session: UserSession = {
      role: 'patient',
      name: DEMO_PATIENT.name,
      email: DEMO_PATIENT.email,
      details: DEMO_PATIENT,
    };
    onLoginSuccess(session);
    onClose();
  };

  const handleDemoDoctorLogin = () => {
    setError('');
    const session: UserSession = {
      role: 'doctor',
      name: 'Dr. Sarah Jenkins, MD',
      email: 'dr.jenkins@staff.apexcare.org',
      details: {
        name: 'Dr. Sarah Jenkins, MD',
        title: 'Chief Tele-Triage Physician',
        dept: 'Emergency Medicine & Triage',
        id: 'DOC-55829',
      },
    };
    onLoginSuccess(session);
    onClose();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (tab === 'register') {
      if (!fullName.trim() || !email.trim() || !password.trim()) {
        setError('Please fill in all required fields.');
        return;
      }
      setSuccessMsg('Account created successfully! Logging you in...');
      setTimeout(() => {
        onLoginSuccess({
          role: 'patient',
          name: fullName,
          email,
          details: {
            ...DEMO_PATIENT,
            name: fullName,
            email,
          },
        });
        setSuccessMsg('');
        onClose();
      }, 700);
      return;
    }

    if (!email.trim() || !password.trim()) {
      setError('Please provide your registered email and password.');
      return;
    }

    // Standard credential sign-in
    if (tab === 'doctor') {
      onLoginSuccess({
        role: 'doctor',
        name: email.split('@')[0].toUpperCase(),
        email,
        details: {
          name: email.split('@')[0],
          title: 'Attending Staff Clinician',
          dept: 'Clinical Operations',
          id: 'STAFF-1092',
        },
      });
    } else {
      onLoginSuccess({
        role: 'patient',
        name: email.split('@')[0],
        email,
        details: {
          ...DEMO_PATIENT,
          name: email.split('@')[0],
          email,
        },
      });
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Modal Top Header */}
        <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center border border-teal-500/30">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white tracking-tight">ApexCare Secure Portal</h2>
              <p className="text-xs text-slate-300">HIPAA Compliant & Encrypted Sign-In</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close modal"
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Portal Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50/70 p-1">
          <button
            type="button"
            onClick={() => { setTab('patient'); setError(''); }}
            className={`flex-1 py-2.5 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              tab === 'patient'
                ? 'bg-white text-teal-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Patient Portal</span>
          </button>
          <button
            type="button"
            onClick={() => { setTab('doctor'); setError(''); }}
            className={`flex-1 py-2.5 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              tab === 'doctor'
                ? 'bg-white text-teal-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Stethoscope className="w-3.5 h-3.5" />
            <span>Staff Clinician</span>
          </button>
          <button
            type="button"
            onClick={() => { setTab('register'); setError(''); }}
            className={`flex-1 py-2.5 text-xs font-semibold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
              tab === 'register'
                ? 'bg-white text-teal-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>New Patient</span>
          </button>
        </div>

        {/* Body Form */}
        <div className="p-6">
          {error && (
            <div className="mb-4 p-3 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg">
              {error}
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 text-xs text-teal-800 bg-teal-50 border border-teal-200 rounded-lg flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-600" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Quick Demo Access Bar */}
          <div className="mb-5 p-3 rounded-xl bg-teal-50/60 border border-teal-100">
            <span className="block text-xs font-medium text-teal-900 mb-2">Instant Demo Session:</span>
            {tab === 'doctor' ? (
              <button
                type="button"
                onClick={handleDemoDoctorLogin}
                className="w-full py-2 px-3 text-xs font-medium text-teal-800 bg-white hover:bg-teal-50 border border-teal-200 rounded-lg shadow-xs transition-colors flex items-center justify-between"
              >
                <span>Sign in as Dr. Sarah Jenkins (Chief Triage)</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleDemoPatientLogin}
                className="w-full py-2 px-3 text-xs font-medium text-teal-800 bg-white hover:bg-teal-50 border border-teal-200 rounded-lg shadow-xs transition-colors flex items-center justify-between"
              >
                <span>Sign in as Sarah Miller (Active Patient)</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {tab === 'register' && (
              <>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Legal Full Name</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. John Doe"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">Mobile Phone (for SMS Verification)</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="(555) 000-0000"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                {tab === 'doctor' ? 'Hospital Staff ID or Email' : 'Email Address'}
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={tab === 'doctor' ? 'doctor@staff.apexcare.org' : 'patient@example.com'}
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
              <label className="flex items-center gap-1.5 cursor-pointer">
                <input type="checkbox" defaultChecked className="rounded border-slate-300 text-teal-600 focus:ring-teal-500" />
                <span>Keep me signed in</span>
              </label>
              <button
                type="button"
                onClick={() => alert('Password reset link sent to your registered email.')}
                className="text-teal-700 hover:underline"
              >
                Forgot Password?
              </button>
            </div>

            <button
              type="submit"
              className="w-full mt-2 py-2.5 px-4 bg-teal-700 hover:bg-teal-800 text-white font-medium text-sm rounded-lg shadow-sm transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <span>{tab === 'register' ? 'Complete Patient Registration' : 'Access Clinical Portal'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <p className="mt-4 text-[11px] text-center text-slate-400">
            Protected by 256-bit AES encryption & 2-Factor Authentication protocols.
          </p>
        </div>
      </div>
    </div>
  );
};
