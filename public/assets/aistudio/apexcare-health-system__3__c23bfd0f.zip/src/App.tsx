import React, { useState, useEffect } from 'react';
import { Header, NavTab } from './components/Header';
import { Footer } from './components/Footer';
import { HomeView } from './components/HomeView';
import { AboutView } from './components/AboutView';
import { HelplineView } from './components/HelplineView';
import { QuickCareView } from './components/QuickCareView';
import { FacilitiesView } from './components/FacilitiesView';
import { ContactView } from './components/ContactView';
import { AuthModal, UserSession } from './components/AuthModal';
import { PatientDashboardModal } from './components/PatientDashboardModal';
import { CallSimulationModal } from './components/CallSimulationModal';
import { BookingModal } from './components/BookingModal';
import { HELPLINE_DATA, HelplineItem } from './data/medicalData';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [session, setSession] = useState<UserSession | null>(null);

  // Modals state
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isDashboardModalOpen, setIsDashboardModalOpen] = useState(false);
  const [isCallModalOpen, setIsCallModalOpen] = useState(false);
  const [activeHelpline, setActiveHelpline] = useState<HelplineItem | null>(null);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [bookingFacilityId, setBookingFacilityId] = useState<string | undefined>(undefined);

  // Restore session from localStorage if present
  useEffect(() => {
    try {
      const saved = localStorage.getItem('apexcare_user_session');
      if (saved) {
        setSession(JSON.parse(saved));
      }
    } catch {
      // Ignore storage errors
    }
  }, []);

  const handleLoginSuccess = (newSession: UserSession) => {
    setSession(newSession);
    try {
      localStorage.setItem('apexcare_user_session', JSON.stringify(newSession));
    } catch {
      // Ignore storage errors
    }
  };

  const handleSignOut = () => {
    setSession(null);
    try {
      localStorage.removeItem('apexcare_user_session');
    } catch {
      // Ignore storage errors
    }
  };

  const handleTriggerSOS = () => {
    setActiveHelpline(HELPLINE_DATA[0]);
    setIsCallModalOpen(true);
  };

  const handleCallHelpline = (item: HelplineItem) => {
    setActiveHelpline(item);
    setIsCallModalOpen(true);
  };

  const handleCallCustomNumber = (phone: string, name: string) => {
    setActiveHelpline({
      id: 'custom-call',
      name,
      number: phone,
      category: 'Emergency',
      availability: '24/7 Operator on Standby',
      avgResponseSeconds: 10,
      description: `Direct hospital operator line to ${name}.`,
      priority: 'HIGH',
    });
    setIsCallModalOpen(true);
  };

  const handleOpenBooking = (facilityId?: string) => {
    setBookingFacilityId(facilityId);
    setIsBookingModalOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      {/* Top Bar with Top Right Login Icon */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        session={session}
        onOpenLogin={() => setIsAuthModalOpen(true)}
        onOpenDashboard={() => setIsDashboardModalOpen(true)}
        onSignOut={handleSignOut}
        onTriggerSOS={handleTriggerSOS}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <HomeView
            onNavigate={setActiveTab}
            onCallHelpline={handleCallHelpline}
            onOpenBooking={() => handleOpenBooking()}
          />
        )}
        {activeTab === 'about' && (
          <AboutView
            onNavigate={setActiveTab}
            onOpenBooking={() => handleOpenBooking()}
          />
        )}
        {activeTab === 'helpline' && (
          <HelplineView onCallHelpline={handleCallHelpline} />
        )}
        {activeTab === 'quick-care' && (
          <QuickCareView
            onNavigate={setActiveTab}
            onOpenBooking={() => handleOpenBooking()}
          />
        )}
        {activeTab === 'facilities' && (
          <FacilitiesView
            onOpenBookingWithFacility={(facId) => handleOpenBooking(facId)}
            onCallNumber={handleCallCustomNumber}
          />
        )}
        {activeTab === 'contact' && <ContactView />}
      </main>

      {/* Footer */}
      <Footer
        onSelectTab={setActiveTab}
        onOpenBooking={() => handleOpenBooking()}
        onTriggerSOS={handleTriggerSOS}
      />

      {/* Modals & Overlays */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      {session && (
        <PatientDashboardModal
          isOpen={isDashboardModalOpen}
          onClose={() => setIsDashboardModalOpen(false)}
          session={session}
          onSignOut={handleSignOut}
          onOpenBooking={() => {
            setIsDashboardModalOpen(false);
            handleOpenBooking();
          }}
        />
      )}

      <CallSimulationModal
        isOpen={isCallModalOpen}
        onClose={() => setIsCallModalOpen(false)}
        helpline={activeHelpline}
      />

      <BookingModal
        isOpen={isBookingModalOpen}
        onClose={() => setIsBookingModalOpen(false)}
        defaultFacilityId={bookingFacilityId}
      />
    </div>
  );
}
